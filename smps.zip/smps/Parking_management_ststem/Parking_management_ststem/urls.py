"""Parking_management_ststem URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from application1 import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('login/', views.test_case1),
    path('a/', views.test_case2,name='a'),
    path('b/', views.test_case1,name='b'),
    path('update_vehicle/<int:pk>', views.update_vehicle,name='update_vehicle'),
    path('delete_vehicle/<int:pk>', views.delete_vehicle,name='delete_vehicle'),
    path('active_parking/<int:pk>', views.active_parking,name='active_parking'),
    path('deactivate_parking/<int:pk>', views.deactivate_parking,name='deactivate_parking'),
    path('c/', views.test_case3,name='c'),
    path('d/', views.test_case4,name='d'),
    path('e/', views.test_case5,name='e'),
    path('f/', views.test_case6,name='f'),
    path('g/', views.test_case7,name='g'),
    path('h/', views.test_case8,name='h'),
    path('i/', views.test_case9,name='i'),
  
]

from django.contrib import admin

# Register your models here
from.models import add_vehicle
from .models import category

class categoryAdmin(admin.ModelAdmin):
    list_display=('id','parking_area_no','vehicle_type','vehicle_limit','parking_charge','status','created_time')
    list_display_links=('id','parking_area_no','vehicle_type')
    list_filter=('id','parking_area_no','vehicle_type','vehicle_limit','parking_charge','status','created_time')
    list_editable=('status','parking_charge','vehicle_limit')
    search_fields=('id','parking_area_no','vehicle_type','vehicle_limit','parking_charge','status','created_time')
    ordering=('created_time',)

admin.site.register(category,categoryAdmin)

class add_vehicleAdmin(admin.ModelAdmin):
    list_display=('id','vehicle_no','parking_area_no','vehicle_type','parking_charge','status','araival_time',)
    list_display_links=('id','vehicle_no') 
    list_filter=('id','vehicle_no','parking_area_no','vehicle_type','parking_charge','status','araival_time',)
    list_editable=('status','parking_charge',)
    search_fields=('id','vehicle_no','parking_area_no','vehicle_type','parking_charge','status','araival_time')
    ordering=('araival_time',)
    
admin.site.register(add_vehicle,add_vehicleAdmin)

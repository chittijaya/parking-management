from django.shortcuts import render,redirect,reverse
from .models import add_vehicle
from .models import category



def test_case1(request):
    return render(request,"login.html")


def test_case2(request):
    return render(request,"Dash_board.html")



# category starts hear
def test_case3(request):

    if request.method == 'POST':
        parking_area_no=request.POST.get("parking_area_no")
        vehicle_type=request.POST.get("vehicle_type")
        vehicle_limit=request.POST.get("vehicle_limit")
        parking_charge=request.POST.get("parking_charge")
        data=category(parking_area_no=parking_area_no, vehicle_type=vehicle_type, vehicle_limit=vehicle_limit, parking_charge=parking_charge)
        data.save()


    add_category=category.objects.all
    context={
        'add_category':add_category
    }
    return render(request,"Category.html",context)



def update_vehicle(request,pk):
    edit_category=category.objects.get(id=pk)
    
    if request.method=="POST":
    
        edit_category.parking_area_no = request.POST.get("parking_area_no")
        edit_category.vehicle_type = request.POST.get("vehicle_type")
        edit_category.vehicle_limit = request.POST.get("vehicle_limit")
        edit_category.parking_charge = request.POST.get("parking_charge")
        
        edit_category.save()
    
        return redirect(reverse("c"))
    context={
    "edit_category": edit_category
    }
    return render(request,'update_category.html',context)
    
    

def delete_vehicle(request,pk):
    add_category=category.objects.get(id=pk)
    add_category.delete()
    
    return redirect(reverse("c"))

def deactivate_parking(request,pk):
    deactivate=category.objects.get(id=pk)
    deactivate.status == False
    deactivate.save()
    return redirect(reverse("c"))

def active_parking(request,pk):
    active=category.objects.get(id=pk)
    active.status == True
    active.save()
    return redirect(reverse("c"))

    
# vehicle entry starts hear
def test_case4(request):

    if request.method == 'POST':
        vehicle_no=request.POST.get("vehicle_no")
        vehicle_type=request.POST.get("vehicle_type")
        parking_area_no=request.POST.get("parking_area_no")
        parking_charge=request.POST.get("parking_charge")
        data=add_vehicle(vehicle_no=vehicle_no, vehicle_type=vehicle_type, parking_area_no=parking_area_no, parking_charge=parking_charge)
        data.save()

        
    vehicle_entry=add_vehicle.objects.all
    context={
        'vehicle_entry':vehicle_entry
    }
    return render(request,"Vehical_entry.html",context)




# manage vehicle starts hear
def test_case5(request):
    manage=add_vehicle.objects.all
    context={
        'manage':manage
    }
    return render(request,"Manage_vehicals.html",context)


def test_case6(request):
    return render(request,"Reports.html")


def test_case7(request):
    srch=add_vehicle.objects.all
    context={
        'srch':srch
    }
    return render(request,"Search.html",context)


def test_case8(request):
    return render(request,"Acount_settings.html")


def test_case9(request):
    return render(request,"logout.html")



    
from django.db import models
from datetime import datetime

class category(models.Model):
    parking_area_no=models.IntegerField(null=False,blank=False)
    vehicle_type=models.CharField(max_length=100,null=False,blank=False)
    vehicle_limit=models.IntegerField(null=False,blank=False)
    parking_charge=models.DecimalField(max_digits=5,decimal_places=2,null=False,blank=False)
    status=models.BooleanField(default=True)
    created_time=models.DateTimeField(default=datetime.now)

class add_vehicle(models.Model):
    category_Id=models.ForeignKey(category,on_delete=models.CASCADE, default=True, null=False)
    vehicle_no=models.CharField(max_length=200, null=False, blank=False)
    parking_area_no=models.IntegerField(null=False,blank=False)
    vehicle_type=models.CharField(max_length=200, null=False, blank=False)
    parking_charge=models.DecimalField(max_digits=5,decimal_places=2)
    status=models.BooleanField(default=True)
    araival_time=models.DateTimeField(default=datetime.now)
    
    def _str_(self):
        return self.vehicle_no
